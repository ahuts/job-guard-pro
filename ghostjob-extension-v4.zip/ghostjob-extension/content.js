// GhostJob Content Script v4
// Self-contained: does NOT rely on background service worker for scanning.
// The MV3 service worker dies after ~30s idle, making chrome.runtime invalid.
// Solution: fetch the API and run analysis directly here in the content script.

(function () {
  'use strict';

  if (window.__ghostJobRunning) return;
  window.__ghostJobRunning = true;

  const BTN_ID   = 'ghostjob-scan-btn';
  const FLOAT_ID = 'ghostjob-float-btn';
  const MODAL_ID = 'ghostjob-modal-overlay';
  const API_URL  = 'https://jobghost-gamma.vercel.app/api/scrape-job';

  function log(...a)  { console.log('[GhostJob]', ...a); }
  function warn(...a) { console.warn('[GhostJob]', ...a); }

  log('v4 loaded on', location.href);

  // ─── Poll helper ──────────────────────────────────────────────────────────
  function poll(fn, interval, timeout) {
    return new Promise(function(resolve, reject) {
      var r = fn(); if (r) { resolve(r); return; }
      var elapsed = 0;
      var t = setInterval(function() {
        elapsed += interval;
        var r = fn();
        if (r) { clearInterval(t); resolve(r); return; }
        if (elapsed >= timeout) { clearInterval(t); reject(new Error('timeout')); }
      }, interval);
    });
  }

  // ─── Find Save button (DOM-agnostic) ──────────────────────────────────────
  function findSaveButton() {
    var all = Array.from(document.querySelectorAll('button'));

    // aria-label containing "save" but not "unsave"
    var b = all.find(function(b) {
      var l = (b.getAttribute('aria-label') || '').toLowerCase();
      return l.indexOf('save') !== -1 && l.indexOf('unsave') === -1;
    });
    if (b) return b;

    // text content = "save" or "save job"
    b = all.find(function(b) {
      var t = (b.textContent || '').trim().toLowerCase();
      return t === 'save' || t === 'save job';
    });
    return b || null;
  }

  // ─── Find flex container that holds the Save button ───────────────────────
  function findButtonContainer() {
    var save = findSaveButton();
    if (save) {
      // Walk up until we find a flex row with ≥2 children
      var node = save.parentElement, depth = 0;
      while (node && depth < 6) {
        var d = window.getComputedStyle(node).display;
        if ((d === 'flex' || d === 'inline-flex') && node.children.length >= 2) {
          return { container: node, insertAfter: save };
        }
        node = node.parentElement; depth++;
      }
      return { container: save.parentElement, insertAfter: save };
    }

    // Fallback: known container fragments
    var frags = ['top-buttons','apply-options','job-actions','top-card__cta','unified-top-card__content'];
    for (var i = 0; i < frags.length; i++) {
      var el = document.querySelector('[class*="' + frags[i] + '"]');
      if (el) return { container: el, insertAfter: null };
    }
    return null;
  }

  // ─── Create inline button ─────────────────────────────────────────────────
  function createGhostButton() {
    var btn = document.createElement('button');
    btn.id   = BTN_ID;
    btn.type = 'button';
    btn.style.cssText = [
      'display:inline-flex','align-items:center','justify-content:center',
      'gap:4px','padding:6px 16px','border-radius:16px',
      'border:1.5px solid #7c3aed',
      'background:linear-gradient(135deg,#667eea 0%,#7c3aed 100%)',
      'color:#fff','font-size:14px','font-weight:600','cursor:pointer',
      'white-space:nowrap','flex-shrink:0','line-height:1.4',
      'transition:opacity .15s','box-sizing:border-box',
      'margin-left:8px','min-height:32px','font-family:inherit',
    ].join(';');
    btn.textContent = '👻 Scan for Ghost Job';
    btn.addEventListener('mouseenter', function() { btn.style.opacity='0.85'; });
    btn.addEventListener('mouseleave', function() { btn.style.opacity='1'; });
    btn.addEventListener('click', handleScanClick);
    return btn;
  }

  // ─── Create floating badge ────────────────────────────────────────────────
  function ensureFloatingBadge() {
    if (document.getElementById(FLOAT_ID)) return;
    var b = document.createElement('button');
    b.id = FLOAT_ID; b.type = 'button'; b.title = 'Scan for Ghost Job';
    b.textContent = '👻';
    b.style.cssText = [
      'position:fixed','bottom:24px','right:24px','width:54px','height:54px',
      'border-radius:50%','background:linear-gradient(135deg,#667eea 0%,#7c3aed 100%)',
      'color:#fff','border:none','font-size:26px','cursor:pointer',
      'z-index:2147483647','box-shadow:0 4px 16px rgba(0,0,0,.35)',
      'display:flex','align-items:center','justify-content:center',
      'transition:transform .15s',
    ].join(';');
    b.addEventListener('mouseenter', function(){ b.style.transform='scale(1.1)'; });
    b.addEventListener('mouseleave', function(){ b.style.transform='scale(1)'; });
    b.addEventListener('click', handleScanClick);
    document.body.appendChild(b);
    log('Floating badge added');
  }

  // ─── Inject inline button ─────────────────────────────────────────────────
  function injectInlineButton() {
    if (document.getElementById(BTN_ID)) return true;
    var found = findButtonContainer();
    if (!found) { warn('No container found'); return false; }
    var btn = createGhostButton();
    if (found.insertAfter) {
      found.insertAfter.insertAdjacentElement('afterend', btn);
      log('Injected after Save button');
    } else {
      found.container.appendChild(btn);
      log('Appended to container');
    }
    return true;
  }

  // ─── Run injection ────────────────────────────────────────────────────────
  function runInjection() {
    if (location.href.indexOf('/jobs/view/') === -1) return;
    var old = document.getElementById(BTN_ID);
    if (old) old.remove();

    poll(function() { return findSaveButton() || findButtonContainer(); }, 300, 15000)
      .then(function() { injectInlineButton(); })
      .catch(function() { warn('Poll timed out'); })
      .finally(function() { ensureFloatingBadge(); });
  }

  // ─── SPA nav watcher ──────────────────────────────────────────────────────
  var lastUrl = location.href, navTimer = null;
  new MutationObserver(function() {
    var url = location.href;
    if (url === lastUrl) return;
    lastUrl = url;
    clearTimeout(navTimer);
    var ob = document.getElementById(BTN_ID); if (ob) ob.remove();
    var of = document.getElementById(FLOAT_ID); if (of) of.remove();
    if (url.indexOf('/jobs/view/') !== -1) navTimer = setTimeout(runInjection, 400);
  }).observe(document, { subtree: true, childList: true });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', runInjection);
  } else {
    runInjection();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // SCAN – runs entirely in content script, no background needed
  // ─────────────────────────────────────────────────────────────────────────

  function handleScanClick() {
    log('Scan clicked');
    var btn = document.getElementById(BTN_ID);
    var origText = btn ? btn.textContent : '👻 Scan for Ghost Job';

    function setLoading(on) {
      if (!btn) return;
      btn.textContent = on ? '⏳ Analysing…' : origText;
      btn.disabled    = on;
      btn.style.opacity = on ? '0.65' : '1';
    }

    setLoading(true);

    var jobData = extractJobData();
    log('Job data:', jobData);

    // First try the remote API; fall back to local scoring if it fails
    fetchRemoteAnalysis(jobData)
      .then(function(data) {
        setLoading(false);
        showGhostScore(data);
      })
      .catch(function(err) {
        warn('API failed, using local scoring:', err.message);
        var analysis = calculateLocalScore(jobData);
        setLoading(false);
        showGhostScore({
          ghostScore:     analysis.score,
          signals:        analysis.signals,
          summary:        analysis.summary,
          recommendation: analysis.recommendation,
          source:         'local'
        });
      });
  }

  // ─── Remote API call (content script fetch – no background needed) ────────
  function fetchRemoteAnalysis(jobData) {
    return fetch(API_URL, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({
        url:         jobData.url,
        title:       jobData.title,
        company:     jobData.company,
        location:    jobData.location,
        description: jobData.description
      })
    })
    .then(function(res) {
      if (!res.ok) return res.json().then(function(e) { throw new Error(e.error || 'HTTP ' + res.status); });
      return res.json();
    })
    .then(function(data) {
      if (!data.success) throw new Error(data.error || 'API unsuccessful');
      // Merge server data with local scoring signals
      var analysis = calculateLocalScore(data.data || jobData);
      return Object.assign({}, data.data, {
        ghostScore:     analysis.score,
        signals:        analysis.signals,
        summary:        analysis.summary,
        recommendation: analysis.recommendation,
        source:         'api'
      });
    });
  }

  // ─── Extract job data ─────────────────────────────────────────────────────
  function extractJobData() {
    var data = { url: location.href, title: '', company: '', location: '', description: '' };

    var h1s = Array.from(document.querySelectorAll('h1'));
    var titleEl = h1s.find(function(h) { return h.textContent.trim().length > 2; });
    if (titleEl) data.title = titleEl.textContent.trim();

    var compLink = document.querySelector('a[href*="/company/"]');
    if (compLink) data.company = compLink.textContent.trim();

    var descEl = document.querySelector(
      '.jobs-description-content__text, .show-more-less-html__markup, ' +
      '[class*="description"] .markup, .description__text, [class*="jobs-description"]'
    );
    if (descEl) data.description = descEl.textContent.trim().substring(0, 3000);

    var m = location.href.match(/\/view\/(\d+)/);
    if (m) data.jobId = m[1];

    return data;
  }

  // ─── Local scoring (copy from background.js so it works offline too) ──────
  function calculateLocalScore(jobData) {
    var score = 50, signals = [];
    var title = (jobData.title || '').toLowerCase();
    var desc  = (jobData.description || '').toLowerCase();

    if (/urgent|immediate|asap|start today|start immediately/i.test(title + ' ' + desc)) {
      score -= 12;
      signals.push({ type:'red', icon:'🚨', title:'Urgency Language',
        description:'Words like "urgent" or "ASAP" often indicate high turnover or poor planning.',
        impact:'May signal desperation hiring or replacing someone who left suddenly.',
        advice:'Ask why the position is urgent. Legitimate urgent roles exist but warrant extra scrutiny.' });
    }
    if (/rockstar|ninja|guru|wizard|superstar|unicorn/i.test(title + ' ' + desc)) {
      score -= 10;
      signals.push({ type:'red', icon:'🎸', title:'Buzzy Job Titles',
        description:'Terms like "rockstar" or "ninja" often mask unclear role expectations.',
        impact:'May indicate the company doesn\'t know what they actually need.',
        advice:'Ask for specific responsibilities. Vague titles often lead to role confusion.' });
    }
    if (/competitive salary|commensurate with experience|pay is competitive/i.test(desc)) {
      score -= 8;
      signals.push({ type:'red', icon:'💰', title:'Vague Salary Info',
        description:'"Competitive" without numbers usually means below market rate.',
        impact:'Companies confident in their pay typically share ranges upfront.',
        advice:'Research salary ranges for this role. Ask for the budget early in the process.' });
    }
    if (/wear many hats|fast.?paced|dynamic environment|all.?hands on deck/i.test(desc)) {
      score -= 8;
      signals.push({ type:'red', icon:'🎩', title:'Code for Understaffed',
        description:'"Wear many hats" often means doing 2–3 jobs for 1 salary.',
        impact:'High burnout risk.',
        advice:'Ask about team size and workload.' });
    }
    if (/unlimited pto|unlimited vacation/i.test(desc)) {
      score -= 6;
      signals.push({ type:'red', icon:'🏖️', title:'"Unlimited" PTO',
        description:'"Unlimited" PTO often results in employees taking LESS time off.',
        impact:'No payout for unused time; social pressure not to take breaks.',
        advice:'Ask about average days taken.' });
    }
    // experience red flag
    var expMatch = desc.match(/(\d{1,2})\+?\s*years?\s*(?:of\s*)?experience/i);
    if (expMatch && parseInt(expMatch[1]) >= 5) {
      score -= 6;
      signals.push({ type:'red', icon:'📅', title:'High Experience Requirements',
        description:'Requires ' + expMatch[1] + '+ years – may be unrealistic.',
        impact:'Could indicate they want senior talent at junior/mid pay.',
        advice:'Apply anyway if you\'re close. Requirements are often flexible.' });
    }
    // green flags
    if (/\$\d[\d,]*k?|\d{3,}\s*-\s*\d{3,}/i.test(desc)) {
      score += 10;
      signals.push({ type:'green', icon:'✅', title:'Salary Transparency',
        description:'Specific salary numbers or ranges mentioned.',
        impact:'Shows confidence in compensation and respect for candidate time.',
        advice:'Great sign!' });
    }
    if (/remote|hybrid|flexible|work from home|wfh/i.test(desc)) {
      score += 5;
      signals.push({ type:'green', icon:'🏠', title:'Flexible Work Options',
        description:'Remote or hybrid options mentioned.',
        impact:'Modern work culture that values autonomy.',
        advice:'Verify flexibility is real.' });
    }
    if (/health insurance|401k|dental|vision|benefits package/i.test(desc)) {
      score += 6;
      signals.push({ type:'green', icon:'🏥', title:'Benefits Mentioned',
        description:'Specific benefits listed.',
        impact:'Investment in employee wellbeing.',
        advice:'Ask for details on coverage.' });
    }
    if (/professional development|learning budget|training|growth opportunities/i.test(desc)) {
      score += 5;
      signals.push({ type:'green', icon:'📚', title:'Growth Opportunities',
        description:'Mentions development or learning.',
        impact:'Company invests in employees, not just output.',
        advice:'Ask about specific programs or budgets.' });
    }

    score = Math.max(0, Math.min(100, score));
    var summary, recommendation;
    if (score >= 70) {
      summary = 'Multiple red flags detected. Proceed with extreme caution.';
      recommendation = 'This job shows several warning signs. Ask tough questions in interviews.';
    } else if (score >= 40) {
      summary = 'Mixed signals. Some concerns but also positive indicators.';
      recommendation = 'Worth investigating. Ask specific questions about the red flags.';
    } else {
      summary = 'Strong positive indicators. Likely a legitimate opportunity.';
      recommendation = 'Good signs overall. Still do your due diligence!';
    }
    return { score, signals, summary, recommendation };
  }

  // ─── Show Ghost Score panel ───────────────────────────────────────────────
  function showGhostScore(result) {
    var old = document.getElementById(MODAL_ID);
    if (old) old.remove();

    var score  = result.ghostScore != null ? result.ghostScore : 50;
    var isHigh = score > 70, isMid = score > 40;
    var color  = isHigh ? '#ef4444' : isMid ? '#f59e0b' : '#22c55e';
    var label  = isHigh ? '⚠️ Likely Ghost Job' : isMid ? '⚡ Proceed with Caution' : '✅ Looks Legitimate';

    var signalsHtml = '';
    if (result.signals && result.signals.length) {
      var rows = result.signals.map(function(s) {
        var bg  = s.type==='red'?'#fef2f2':s.type==='green'?'#f0fdf4':'#fefce8';
        var bdr = s.type==='red'?'#ef4444':s.type==='green'?'#22c55e':'#eab308';
        var tbg = s.type==='red'?'#fecaca':s.type==='green'?'#bbf7d0':'#fde047';
        var tfg = s.type==='red'?'#dc2626':s.type==='green'?'#16a34a':'#a16207';
        return '<div style="margin-bottom:12px;padding:10px;border-radius:8px;background:'+bg+';border-left:3px solid '+bdr+'">' +
          '<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">' +
            '<span style="font-size:16px">'+s.icon+'</span>' +
            '<span style="font-weight:600;color:#333;font-size:13px">'+s.title+'</span>' +
            '<span style="margin-left:auto;padding:2px 6px;border-radius:4px;font-size:10px;font-weight:700;text-transform:uppercase;background:'+tbg+';color:'+tfg+'">'+s.type+'</span>' +
          '</div>' +
          '<div style="font-size:12px;color:#555;margin-bottom:4px;padding-left:24px">'+s.description+'</div>' +
          '<div style="font-size:11px;color:#666;padding-left:24px;margin-bottom:4px"><strong>Impact:</strong> '+s.impact+'</div>' +
          '<div style="font-size:11px;color:#2563eb;padding-left:24px"><strong>💡 Tip:</strong> '+s.advice+'</div>' +
        '</div>';
      }).join('');
      signalsHtml = '<div style="margin-top:20px;border-top:1px solid #e5e7eb;padding-top:16px">' +
        '<div style="font-size:14px;font-weight:600;color:#333;margin-bottom:12px">📊 Signals Detected ('+result.signals.length+')</div>' +
        '<div style="max-height:300px;overflow-y:auto">'+rows+'</div></div>';
    }

    var source = result.source === 'local'
      ? '<div style="font-size:11px;color:#999;text-align:center;margin-top:8px">⚡ Local analysis (API unavailable)</div>'
      : '';

    var overlay = document.createElement('div');
    overlay.id = MODAL_ID;
    overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.3);z-index:2147483646;display:flex;align-items:flex-start;justify-content:flex-end;padding:20px;padding-top:80px;box-sizing:border-box';
    overlay.addEventListener('click', function(e) { if (e.target===overlay) overlay.remove(); });

    var panel = document.createElement('div');
    panel.style.cssText = 'background:#fff;border-radius:16px 0 0 16px;width:560px;max-width:90vw;max-height:calc(100vh - 100px);overflow-y:auto;box-shadow:-4px 0 24px rgba(0,0,0,.18);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;border:1px solid #e5e7eb;border-right:none';

    panel.innerHTML =
      '<div style="padding:24px">' +
        '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">' +
          '<div style="font-size:20px;font-weight:700;color:#111">GhostJob Analysis</div>' +
          '<button id="gj-close-x" style="background:none;border:none;font-size:22px;cursor:pointer;color:#666;padding:4px 8px;border-radius:4px;line-height:1">✕</button>' +
        '</div>' +
        '<div style="display:flex;align-items:center;gap:16px;margin-bottom:20px;padding:16px;background:'+color+'12;border-radius:12px">' +
          '<div style="width:76px;height:76px;border-radius:50%;background:'+color+';display:flex;align-items:center;justify-content:center;color:#fff;font-size:26px;font-weight:700;flex-shrink:0">'+score+'</div>' +
          '<div>' +
            '<div style="font-size:17px;font-weight:700;color:'+color+'">'+label+'</div>' +
            '<div style="font-size:13px;color:#666;margin-top:4px">Ghost Score: '+score+' / 100</div>' +
          '</div>' +
        '</div>' +
        (result.summary ? '<div style="font-size:14px;color:#444;margin-bottom:16px;padding:12px;background:#f9fafb;border-radius:8px;border-left:3px solid '+color+'"><strong>Summary:</strong> '+result.summary+'</div>' : '') +
        signalsHtml +
        (result.recommendation ? '<div style="margin-top:16px;padding:12px;background:#f9fafb;border-radius:8px;border-left:3px solid '+color+'"><div style="font-size:14px;color:#444"><strong>🎯 Recommendation:</strong> '+result.recommendation+'</div></div>' : '') +
        '<div style="margin-top:24px;display:flex;gap:12px">' +
          '<button id="gj-save-btn" style="flex:1;padding:11px 20px;background:#667eea;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;font-family:inherit">💾 Save to Dashboard</button>' +
          '<button id="gj-close-btn" style="padding:11px 20px;background:#f3f4f6;color:#374151;border:1px solid #d1d5db;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;font-family:inherit">Close</button>' +
        '</div>' +
        source +
        '<div id="gj-save-status" style="margin-top:10px;font-size:13px;text-align:center"></div>' +
      '</div>';

    overlay.appendChild(panel);
    document.body.appendChild(overlay);
    document.getElementById('gj-close-x').addEventListener('click', function(){ overlay.remove(); });
    document.getElementById('gj-close-btn').addEventListener('click', function(){ overlay.remove(); });
    document.getElementById('gj-save-btn').addEventListener('click', function(){ handleSaveJob(result); });
  }

  // ─── Save job (tries background, falls back to localStorage) ─────────────
  function handleSaveJob(result) {
    var saveBtn   = document.getElementById('gj-save-btn');
    var statusDiv = document.getElementById('gj-save-status');
    if (!saveBtn || !statusDiv) return;
    saveBtn.disabled = true;
    saveBtn.textContent = '💾 Saving…';

    var jobData = extractJobData();
    var payload = Object.assign({}, jobData, {
      ghostScore: result.ghostScore,
      signals:    result.signals,
      summary:    result.summary,
      scannedAt:  new Date().toISOString()
    });

    function onSaved(totalSaved) {
      saveBtn.textContent     = '✅ Saved!';
      saveBtn.style.background = '#22c55e';
      statusDiv.textContent   = 'Saved (' + totalSaved + ' total)';
      statusDiv.style.color   = '#22c55e';
      setTimeout(function(){
        saveBtn.textContent     = '💾 Save to Dashboard';
        saveBtn.style.background = '#667eea';
        saveBtn.disabled        = false;
        statusDiv.textContent   = '';
      }, 3000);
    }

    function onError(msg) {
      saveBtn.textContent     = '❌ Failed';
      saveBtn.style.background = '#ef4444';
      statusDiv.textContent   = msg || 'Save failed';
      statusDiv.style.color   = '#ef4444';
      setTimeout(function(){
        saveBtn.textContent     = '💾 Save to Dashboard';
        saveBtn.style.background = '#667eea';
        saveBtn.disabled        = false;
        statusDiv.textContent   = '';
      }, 3000);
    }

    // Try background first; if context dead, fall back to chrome.storage direct
    try {
      chrome.runtime.sendMessage({ action: 'saveJob', jobData: payload }, function(response) {
        if (chrome.runtime.lastError || !response) {
          // Background dead – save via storage API directly
          saveViaStorageDirect(payload, onSaved, onError);
          return;
        }
        if (response.success) onSaved(response.data.totalSaved);
        else onError(response.error);
      });
    } catch(e) {
      saveViaStorageDirect(payload, onSaved, onError);
    }
  }

  function saveViaStorageDirect(jobData, onSaved, onError) {
    try {
      chrome.storage.local.get('savedJobs', function(result) {
        var jobs = (result.savedJobs || []);
        jobs.unshift(Object.assign({ id: Date.now().toString() }, jobData));
        if (jobs.length > 100) jobs.pop();
        chrome.storage.local.set({ savedJobs: jobs }, function() {
          onSaved(jobs.length);
        });
      });
    } catch(e) {
      onError('Could not save: ' + e.message);
    }
  }

  // ─── Popup message handler ────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener(function(request, _sender, sendResponse) {
    if (request.action === 'ping') {
      sendResponse({ success: true, url: location.href });
      return true;
    }
    if (request.action === 'scanFromPopup') {
      var jobData = extractJobData();
      fetchRemoteAnalysis(jobData)
        .catch(function() {
          var a = calculateLocalScore(jobData);
          return Object.assign(a, { ghostScore: a.score, source: 'local' });
        })
        .then(function(data) {
          showGhostScore(data);
          sendResponse({ success: true, data: data });
        });
      return true;
    }
  });

})();
